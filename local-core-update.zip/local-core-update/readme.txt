=== Local Core Update ===
Contributors: marko88
Donate link: 
Tags: update, core, local, local update, wp update
Requires at least: 4.2
Tested up to: 4.3.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

If your WP Site is unable to Automatically Update to next/latest version, due to hosting company restrictions or is simply unable to download newest version, this plugin might help. This plugin enables you update WordPress via Automatic Update with .zip file. Copy WP Installation .zip file to /wp-content, and update as usual, Click Dashboard > Updates > Update Now or Re-install Now. DEACTIVATE this plugin when updating themes or plugins, probably is the best to activate it ONLY when updating WordPress Core.

== Installation ==

Here is 2 options, first for latest version installation and second for installing any version.

1.Upgrade to latest version

	1. Activate the plugin 'Local Core Update' through the 'Plugins' menu in WordPress
	2. Go to Dashboard > Updates > Update Now or Re-install Now, there you will be provided the link for downloading latest version (wordpress-x.x-no-content.zip)
	3. Download .zip file and upload it to /wp-content
	4. Go again to update Dashboard > Updates > Update Now or Re-install Now

2.Install any version

	1. Activate the plugin 'Local Core Update' through the 'Plugins' menu in WordPress
	2. Download Version you want to install
	3. Rename installation file to wordpress.zip file and upload it to /wp-content
	4. Go to Dashboard > Updates > Update Now or Re-install Now

== Frequently Asked Questions ==

None so far.

== Screenshots ==

1. Shows help info in 'Update' menu

== Changelog ==

= 1.0 =
* First verion

== Upgrade Notice ==

None so far.


<?php

/* Checks if wp is processing requets for downloading new release, not theme or plugin update */
if( strpos( $package, 'https://downloads.wordpress.org/release') !== FALSE ) {

	/* Saving original $package variables */
	$package_wp = $package;
	$package_file = str_replace('https://downloads.wordpress.org/release/', '', $package);

	/* Creating latest wp installation file variables */
	$package_latest = str_replace('https://downloads.wordpress.org/release/', ABSPATH.'wp-content'.DIRECTORY_SEPARATOR, $package);
	$package_latest_local = str_replace(ABSPATH, DIRECTORY_SEPARATOR, $package_latest);

	/* Creating custom wp installation file variables */
	$package_any = str_replace($package_file, 'wordpress.zip', $package_latest);
	$package_any_local = str_replace(ABSPATH, DIRECTORY_SEPARATOR, $package_any);

	/* Checks if files exist */
	if (file_exists($package_latest)) {
		$package = $package_latest;
		$package_local = $package_latest_local;
	} else {
		$package = $package_any;
		$package_local = $package_any_local;
	}

	/* Printing error page if files doesn't exists, and exit() */
	echo "<p style='font-size:130%;color:red'>Plugin <b>Local Core Update</b> is ACTIVATED!</p>";
	if (!file_exists($package)) {
		exit ("
		<p style='font-size:150%'>1.Upgrade to latest version</p>
		<p>==================================================</p>
		<p>$package_latest_local <b style='color:red;font-size:130%'>don't exists!!!</b></p>
		<p>1. Download latest WP from: <a href='$package_wp'>$package_wp</a></p>
		<p>2. Upload it to: $package_latest_local</p>
		<p>3. And try again!</p>
		<p style='font-size:150%'>2.Install any version</p>
		<p>==================================================</p>
		<p>$package_any_local <b style='color:red;font-size:130%'>don't exists!!!</b></p>
		<p>1. Rename WP installation zip file to: wordpress.zip
		<p>2. Upload it to: $package_any_local</p>
		<p>3. And try again!</p>
		<br>
		<p style='font-size:140%;color:green'>After upgrade installation .zip file will be deleted!</p>
		");
	}

	/* If one of the files exist, continues with update */
	echo "<p style='font-size:120%'>Installing <b>$package_local</b></p>";

	return $package;

}
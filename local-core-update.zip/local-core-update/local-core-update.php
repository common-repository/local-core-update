<?php
/*
Plugin Name: Local Core Update
Plugin URI:  http://marko88.cf/wp-plugins/local-core-update.tar.gz
Description: If your WP Site is unable to Automatically Update to next/latest version, due to hosting company restrictions or is simply unable to download newest version, this plugin might help. This plugin enables you update WordPress via Automatic Update with .zip file. Copy WP Installation .zip file to /wp-content, and update as usual, Click Dashboard > Updates > Update Now or Re-install Now. DEACTIVATE this plugin when updating themes or plugins, probably is the best to activate it ONLY when updating WordPress Core.
Version:     1.0
Author:      marko88
Author URI:  http://marko88.cf
License:     GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Domain Path: /languages
Text Domain: local-core-update
*/

function lcu_put_embed_code() {

	$lcu_file = ABSPATH . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'class-wp-upgrader.php';
	$lcu_file_array = file( $lcu_file );

	if ( !strpos( file_get_contents( $lcu_file ), 'lcu732emb534cd88' ) ) {

		$embed_text = "		include '" . __DIR__ . DIRECTORY_SEPARATOR . "embed_code.php' ; /* local-core-update plugin embed code, lcu732emb534cd88 */\n";

		foreach ($lcu_file_array as $key => $line) {

			if ( strpos( $line, 'function download_package' ) ) {

				$lcu_file_array[$key] = $line . $embed_text;

			}

		}

		file_put_contents( $lcu_file, implode( '', $lcu_file_array) );
	}
}

function lcu_remove_embed_code() {

	$lcu_file = ABSPATH . 'wp-admin' . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'class-wp-upgrader.php';
	$lcu_file_array = file( $lcu_file );

	if ( strpos( file_get_contents( $lcu_file ), 'lcu732emb534cd88' ) ) {

		foreach ($lcu_file_array as $key => $line) {

			if ( strpos( $line, 'lcu732emb534cd88' ) ) {

				unset( $lcu_file_array[$key] );

			}

		}

		file_put_contents( $lcu_file, implode( '', $lcu_file_array) );

	}
}

add_action( 'admin_init', 'lcu_put_embed_code' );

register_activation_hook( __FILE__, 'lcu_put_embed_code' );

register_deactivation_hook( __FILE__, 'lcu_remove_embed_code' );